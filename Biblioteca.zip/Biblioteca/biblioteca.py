import tkinter as tk
from tkinter import messagebox, ttk
import sqlite3

# Criação do banco de dados e tabelas
conn = sqlite3.connect('biblioteca.db')
cursor = conn.cursor()
cursor.execute('''
CREATE TABLE IF NOT EXISTS autores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL UNIQUE
)
''')
cursor.execute('''
CREATE TABLE IF NOT EXISTS livros (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo TEXT NOT NULL,
    autor_id INTEGER NOT NULL,
    FOREIGN KEY (autor_id) REFERENCES autores(id) ON DELETE CASCADE
)
''')
conn.commit()

# Dicionário para mapear autores
autores_dict = {}

# Funções CRUD
def inserir_autor():
    nome = entry_autor.get().strip()
    if not nome:
        messagebox.showerror("Erro", "Nome do autor não pode ser vazio.")
        return
    try:
        cursor.execute("INSERT INTO autores (nome) VALUES (?)", (nome,))
        conn.commit()
        entry_autor.delete(0, tk.END)
        listar_autores()
        messagebox.showinfo("Sucesso", "Autor cadastrado com sucesso!")
    except sqlite3.IntegrityError:
        messagebox.showerror("Erro", "Autor já existe no banco de dados.")

def editar_autor():
    selecionado = listbox_autores.curselection()
    if not selecionado:
        messagebox.showwarning("Aviso", "Selecione um autor para editar.")
        return
    
    autor_atual = listbox_autores.get(selecionado[0]).split(" - ")[1]
    novo_nome = entry_autor.get().strip()
    
    if not novo_nome:
        messagebox.showerror("Erro", "Nome do autor não pode ser vazio.")
        return
    
    try:
        cursor.execute("UPDATE autores SET nome=? WHERE nome=?", (novo_nome, autor_atual))
        conn.commit()
        entry_autor.delete(0, tk.END)
        listar_autores()
        messagebox.showinfo("Sucesso", "Autor atualizado com sucesso!")
    except sqlite3.IntegrityError:
        messagebox.showerror("Erro", "Autor já existe no banco de dados.")

def deletar_autor():
    selecionado = listbox_autores.curselection()
    if not selecionado:
        messagebox.showwarning("Aviso", "Selecione um autor para deletar.")
        return
    
    autor_id = listbox_autores.get(selecionado[0]).split(" - ")[0]
    
    if messagebox.askyesno("Confirmar", "Tem certeza que deseja deletar este autor e todos os seus livros?"):
        cursor.execute("DELETE FROM autores WHERE id=?", (autor_id,))
        conn.commit()
        listar_autores()
        listar_livros()
        messagebox.showinfo("Sucesso", "Autor e seus livros foram removidos com sucesso!")

def inserir_livro():
    titulo = entry_titulo.get().strip()
    autor = combo_autores.get()
    if not titulo or not autor:
        messagebox.showerror("Erro", "Preencha todos os campos.")
        return
    
    autor_id = autores_dict.get(autor)
    try:
        cursor.execute("INSERT INTO livros (titulo, autor_id) VALUES (?, ?)", (titulo, autor_id))
        conn.commit()
        entry_titulo.delete(0, tk.END)
        listar_livros()
        messagebox.showinfo("Sucesso", "Livro cadastrado com sucesso!")
    except sqlite3.IntegrityError:
        messagebox.showerror("Erro", "Erro ao inserir livro.")

def editar_livro():
    selected = tree_livros.selection()
    if not selected:
        messagebox.showwarning("Aviso", "Selecione um livro para editar.")
        return
    
    livro_id = tree_livros.item(selected[0])['values'][0]
    novo_titulo = entry_titulo.get().strip()
    novo_autor = combo_autores.get()
    
    if not novo_titulo or not novo_autor:
        messagebox.showerror("Erro", "Preencha todos os campos.")
        return
    
    novo_autor_id = autores_dict.get(novo_autor)
    
    try:
        cursor.execute("UPDATE livros SET titulo=?, autor_id=? WHERE id=?", 
                       (novo_titulo, novo_autor_id, livro_id))
        conn.commit()
        entry_titulo.delete(0, tk.END)
        listar_livros()
        messagebox.showinfo("Sucesso", "Livro atualizado com sucesso!")
    except sqlite3.Error as e:
        messagebox.showerror("Erro", f"Erro ao atualizar livro: {e}")

def deletar_livro():
    selected = tree_livros.selection()
    if not selected:
        messagebox.showwarning("Aviso", "Selecione um livro para deletar.")
        return
    
    livro_id = tree_livros.item(selected[0])['values'][0]
    
    if messagebox.askyesno("Confirmar", "Tem certeza que deseja deletar este livro?"):
        cursor.execute("DELETE FROM livros WHERE id=?", (livro_id,))
        conn.commit()
        listar_livros()
        messagebox.showinfo("Sucesso", "Livro removido com sucesso!")

def listar_autores():
    listbox_autores.delete(0, tk.END)
    combo_autores['values'] = []
    autores_dict.clear()
    cursor.execute("SELECT * FROM autores ORDER BY nome")
    for autor in cursor.fetchall():
        listbox_autores.insert(tk.END, f"{autor[0]} - {autor[1]}")
        autores_dict[autor[1]] = autor[0]
    combo_autores['values'] = list(autores_dict.keys())

def listar_livros(filtro_autor=None):
    for row in tree_livros.get_children():
        tree_livros.delete(row)
    
    query = '''
        SELECT livros.id, livros.titulo, autores.nome 
        FROM livros
        JOIN autores ON livros.autor_id = autores.id
    '''
    
    params = ()
    
    if filtro_autor:
        query += " WHERE autores.nome = ?"
        params = (filtro_autor,)
    
    query += " ORDER BY livros.titulo"
    
    cursor.execute(query, params)
    for livro in cursor.fetchall():
        tree_livros.insert('', tk.END, values=livro)

def listar_livros_por_autor(event=None):
    selecionado = listbox_autores.curselection()
    if selecionado:
        autor = listbox_autores.get(selecionado[0]).split(" - ")[1]
        listar_livros(autor)
    else:
        listar_livros()

def carregar_dados_selecionados(event):
    # Para autores
    selecionado = listbox_autores.curselection()
    if selecionado:
        autor = listbox_autores.get(selecionado[0]).split(" - ")[1]
        entry_autor.delete(0, tk.END)
        entry_autor.insert(0, autor)
    
    # Para livros
    selecionado = tree_livros.selection()
    if selecionado:
        livro = tree_livros.item(selecionado[0])['values']
        entry_titulo.delete(0, tk.END)
        entry_titulo.insert(0, livro[1])
        combo_autores.set(livro[2])

# GUI
root = tk.Tk()
root.title("Sistema de Biblioteca")

# Frame autores
frame_autor = tk.LabelFrame(root, text="Cadastro de Autor")
frame_autor.grid(row=0, column=0, padx=10, pady=10, sticky="ew")

tk.Label(frame_autor, text="Nome:").grid(row=0, column=0, sticky="e")
entry_autor = tk.Entry(frame_autor, width=30)
entry_autor.grid(row=0, column=1, padx=5)

btn_inserir_autor = tk.Button(frame_autor, text="Inserir", command=inserir_autor)
btn_inserir_autor.grid(row=0, column=2, padx=2)

btn_editar_autor = tk.Button(frame_autor, text="Editar", command=editar_autor)
btn_editar_autor.grid(row=0, column=3, padx=2)

btn_deletar_autor = tk.Button(frame_autor, text="Deletar", command=deletar_autor)
btn_deletar_autor.grid(row=0, column=4, padx=2)

listbox_autores = tk.Listbox(frame_autor, height=8, width=50)
listbox_autores.grid(row=1, column=0, columnspan=5, pady=5)
listbox_autores.bind('<<ListboxSelect>>', listar_livros_por_autor)
listbox_autores.bind('<Double-1>', carregar_dados_selecionados)

# Frame livros
frame_livro = tk.LabelFrame(root, text="Cadastro de Livro")
frame_livro.grid(row=1, column=0, padx=10, pady=10, sticky="ew")

tk.Label(frame_livro, text="Título:").grid(row=0, column=0, sticky="e")
entry_titulo = tk.Entry(frame_livro, width=30)
entry_titulo.grid(row=0, column=1, padx=5)

tk.Label(frame_livro, text="Autor:").grid(row=0, column=2, sticky="e")
combo_autores = ttk.Combobox(frame_livro, state="readonly", width=27)
combo_autores.grid(row=0, column=3, padx=5)

btn_inserir_livro = tk.Button(frame_livro, text="Inserir", command=inserir_livro)
btn_inserir_livro.grid(row=0, column=4, padx=2)

btn_editar_livro = tk.Button(frame_livro, text="Editar", command=editar_livro)
btn_editar_livro.grid(row=0, column=5, padx=2)

btn_deletar_livro = tk.Button(frame_livro, text="Deletar", command=deletar_livro)
btn_deletar_livro.grid(row=0, column=6, padx=2)

# Treeview para livros
tree_livros = ttk.Treeview(frame_livro, columns=("ID", "Título", "Autor"), show="headings", height=8)
tree_livros.heading("ID", text="ID")
tree_livros.heading("Título", text="Título")
tree_livros.heading("Autor", text="Autor")
tree_livros.column("ID", width=50, anchor="center")
tree_livros.column("Título", width=200)
tree_livros.column("Autor", width=150)
tree_livros.grid(row=1, column=0, columnspan=7, pady=5)
tree_livros.bind('<Double-1>', carregar_dados_selecionados)

# Botão para mostrar todos os livros
btn_todos_livros = tk.Button(frame_livro, text="Mostrar Todos os Livros", 
                            command=lambda: listar_livros())
btn_todos_livros.grid(row=2, column=0, columnspan=7, pady=5, sticky="ew")

# Inicialização
listar_autores()
listar_livros()

root.mainloop()